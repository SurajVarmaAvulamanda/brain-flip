
import { Difficulty, BestScores, GameStats } from '../types';

const STORAGE_KEY = 'brain_flip_india_best_scores';

export const getBestScores = (): BestScores => {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) {
    return {
      [Difficulty.EASY]: null,
      [Difficulty.MEDIUM]: null,
      [Difficulty.HARD]: null,
    };
  }
  return JSON.parse(data);
};

export const saveBestScore = (stats: GameStats): void => {
  const currentScores = getBestScores();
  const currentBest = currentScores[stats.difficulty];

  // Logic: Better score is fewer moves, or same moves but faster time
  const isBetter = !currentBest || 
                   stats.moves < currentBest.moves || 
                   (stats.moves === currentBest.moves && stats.time < currentBest.time);

  if (isBetter) {
    currentScores[stats.difficulty] = stats;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(currentScores));
  }
};
