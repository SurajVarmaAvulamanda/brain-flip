
import React from 'react';
import { CardData } from '../types';

interface CardProps {
  card: CardData;
  onClick: () => void;
  disabled: boolean;
}

const Card: React.FC<CardProps> = React.memo(({ card, onClick, disabled }) => {
  const isFlipped = card.isFlipped || card.isMatched;

  return (
    <div 
      className={`relative w-full aspect-[4/5] perspective-1000 cursor-pointer touch-manipulation ${disabled ? 'pointer-events-none' : ''}`}
      onClick={(e) => {
        e.preventDefault();
        onClick();
      }}
      role="button"
      aria-label={isFlipped ? `Card value ${card.symbol}` : "Hidden card"}
    >
      <div 
        className={`relative w-full h-full duration-500 transform-style-3d transition-transform ${isFlipped ? 'rotate-y-180' : ''}`}
      >
        {/* Front side (Logo/Pattern) */}
        <div className="absolute inset-0 w-full h-full backface-hidden bg-gradient-to-br from-orange-400 to-orange-600 rounded-lg sm:rounded-xl shadow-md sm:shadow-lg border-2 border-orange-200 flex items-center justify-center">
            <div className="opacity-40 text-2xl sm:text-4xl select-none pointer-events-none">🪷</div>
        </div>

        {/* Back side (The actual symbol) */}
        <div className={`absolute inset-0 w-full h-full backface-hidden rotate-y-180 bg-white rounded-lg sm:rounded-xl shadow-md sm:shadow-lg border-2 ${card.isMatched ? 'border-green-500' : 'border-orange-200'} flex items-center justify-center text-2xl sm:text-4xl select-none`}>
           <span className={`${card.isMatched ? 'animate-bounce' : ''} pointer-events-none`}>
             {card.symbol}
           </span>
        </div>
      </div>
    </div>
  );
});

export default Card;
