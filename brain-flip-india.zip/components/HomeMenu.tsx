
import React, { useState } from 'react';
import { Difficulty, BestScores } from '../types';
import { DIFFICULTY_CONFIG, PLAYER_CONFIG } from '../constants';

interface HomeMenuProps {
  onStartGame: (difficulty: Difficulty, playerCount: number) => void;
  bestScores: BestScores;
}

const HomeMenu: React.FC<HomeMenuProps> = ({ onStartGame, bestScores }) => {
  const [step, setStep] = useState<'players' | 'difficulty'>('players');
  const [playerCount, setPlayerCount] = useState(1);

  const handlePlayerSelect = (count: number) => {
    setPlayerCount(count);
    setStep('difficulty');
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center animate-in fade-in duration-500">
      <div className="mb-8">
        <h1 className="text-4xl md:text-6xl font-bold text-[#FF9933] mb-2 drop-shadow-md">
          Brain Flip
        </h1>
        <h2 className="text-2xl md:text-3xl font-semibold text-[#138808]">
          India Edition
        </h2>
      </div>

      <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-2xl w-full max-w-md border-b-8 border-orange-500 relative overflow-hidden">
        {step === 'players' ? (
          <div className="animate-in slide-in-from-right duration-300">
            <h3 className="text-xl font-semibold mb-6 text-[#3E2723]">How many players?</h3>
            <div className="grid grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((count) => (
                <button
                  key={count}
                  onClick={() => handlePlayerSelect(count)}
                  className="bg-[#FFF9F2] hover:bg-orange-50 border-2 border-orange-200 p-6 rounded-2xl transition-all transform hover:-translate-y-1 active:scale-95 group"
                >
                  <div className="text-2xl mb-1 group-hover:scale-110 transition-transform">
                    {Array.from({ length: count }).map((_, i) => PLAYER_CONFIG[i].icon).join('')}
                  </div>
                  <div className="font-bold text-orange-600 uppercase tracking-widest text-sm">
                    {count} {count === 1 ? 'Player' : 'Players'}
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="animate-in slide-in-from-right duration-300">
            <div className="flex items-center mb-6">
              <button 
                onClick={() => setStep('players')}
                className="p-2 -ml-2 text-gray-400 hover:text-orange-500 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h3 className="flex-1 text-xl font-semibold text-[#3E2723]">Choose Difficulty</h3>
            </div>
            
            <div className="space-y-4">
              {(Object.keys(DIFFICULTY_CONFIG) as Difficulty[]).map((level) => {
                const config = DIFFICULTY_CONFIG[level];
                const best = bestScores[level];

                return (
                  <button
                    key={level}
                    onClick={() => onStartGame(level, playerCount)}
                    className="w-full bg-[#FFF9F2] hover:bg-orange-50 border-2 border-orange-200 py-4 px-6 rounded-2xl transition-all transform hover:-translate-y-1 active:scale-95 text-left"
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="block text-lg font-bold text-orange-600 uppercase tracking-wider">{config.label}</span>
                        <span className="text-xs text-gray-500">{config.rows} x {config.cols} Grid</span>
                      </div>
                      {playerCount === 1 && best && (
                        <div className="text-right">
                          <div className="text-xs text-green-600 font-semibold uppercase">Best</div>
                          <div className="text-sm font-bold text-gray-700">{best.moves} moves</div>
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      <div className="mt-12 flex items-center space-x-4">
        <div className="w-12 h-1 bg-orange-500 rounded-full"></div>
        <span className="text-orange-500 text-2xl">🪷</span>
        <div className="w-12 h-1 bg-green-500 rounded-full"></div>
      </div>

      <footer className="mt-8 text-sm text-gray-400 font-medium">
        Play with friends on the same device
      </footer>
    </div>
  );
};

export default HomeMenu;
