
import React from 'react';
import { Player } from '../types';

interface ScoreBoardProps {
  players: Player[];
  currentPlayerIndex: number;
}

const ScoreBoard: React.FC<ScoreBoardProps> = ({ players, currentPlayerIndex }) => {
  const gridCols = players.length === 1 ? 'grid-cols-1' : 
                   players.length === 2 ? 'grid-cols-2' : 
                   players.length === 3 ? 'grid-cols-3' : 'grid-cols-2 sm:grid-cols-4';

  return (
    <div className={`grid ${gridCols} gap-2 px-3 py-2 bg-white/60 backdrop-blur-md border-b border-orange-100 shadow-sm transition-all duration-300`}>
      {players.map((player, index) => {
        const isActive = index === currentPlayerIndex;
        return (
          <div 
            key={player.id} 
            className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-xl transition-all duration-300 border-2 ${
              isActive 
                ? 'bg-orange-50 border-orange-400 scale-[1.02] shadow-sm ring-2 ring-orange-100' 
                : 'bg-white/50 border-transparent opacity-70'
            }`}
          >
            <div className="flex items-center space-x-1 max-w-full overflow-hidden">
               <span 
                className="flex-shrink-0 w-2 h-2 rounded-full" 
                style={{ backgroundColor: player.color }} 
              />
              <span className={`text-[9px] sm:text-[10px] font-bold uppercase tracking-wider truncate ${isActive ? 'text-orange-600' : 'text-gray-500'}`}>
                {player.name}
              </span>
            </div>
            <div className="flex items-baseline space-x-1">
                <span className={`text-lg sm:text-xl font-black ${isActive ? 'text-orange-700' : 'text-gray-700'}`}>
                {player.score}
                </span>
                {isActive && players.length > 1 && (
                    <span className="text-[8px] font-bold text-orange-500 uppercase animate-pulse">
                        Turn
                    </span>
                )}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default ScoreBoard;
