
import React, { useEffect } from 'react';
import { GameStats, Player } from '../types';
import { audioManager } from '../utils/audioUtils';

interface GameOverModalProps {
  stats: GameStats;
  players: Player[];
  isNewBest: boolean;
  onRestart: () => void;
  onHome: () => void;
}

const GameOverModal: React.FC<GameOverModalProps> = ({ stats, players, isNewBest, onRestart, onHome }) => {
  useEffect(() => {
    audioManager.playWin();
  }, []);

  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
  const winners = sortedPlayers.filter(p => p.score === sortedPlayers[0].score);
  const isDraw = winners.length > 1 && players.length > 1;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white rounded-3xl p-8 w-full max-w-sm shadow-2xl text-center border-t-8 border-orange-500 max-h-[90vh] overflow-y-auto">
        <div className="text-6xl mb-4">🏆</div>
        
        {players.length > 1 ? (
          <>
            <h2 className="text-3xl font-bold text-orange-600 mb-2">
              {isDraw ? "It's a Tie!" : `${winners[0].name} Wins!`}
            </h2>
            <p className="text-gray-600 mb-6">Fantastic performance!</p>
            
            <div className="space-y-3 mb-8">
              {sortedPlayers.map((player, idx) => (
                <div 
                  key={player.id} 
                  className={`flex items-center justify-between p-4 rounded-2xl border-2 ${
                    winners.includes(player) ? 'bg-orange-50 border-orange-400' : 'bg-gray-50 border-transparent'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-xl font-bold text-gray-400">#{idx + 1}</span>
                    <span className="font-bold text-[#3E2723]">{player.name}</span>
                  </div>
                  <span className="text-xl font-black text-orange-600">{player.score}</span>
                </div>
              ))}
            </div>
          </>
        ) : (
          <>
            <h2 className="text-3xl font-bold text-orange-600 mb-2">Shaandar!</h2>
            <p className="text-gray-600 mb-6">Solo mission accomplished!</p>
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-orange-50 rounded-2xl p-4">
                <div className="text-xs text-orange-500 font-bold uppercase">Moves</div>
                <div className="text-2xl font-bold text-[#3E2723]">{stats.moves}</div>
              </div>
              <div className="bg-green-50 rounded-2xl p-4">
                <div className="text-xs text-green-500 font-bold uppercase">Time</div>
                <div className="text-2xl font-bold text-[#3E2723]">{Math.floor(stats.time / 60)}:{(stats.time % 60).toString().padStart(2, '0')}</div>
              </div>
            </div>
            {isNewBest && (
              <div className="mb-6 animate-bounce">
                <span className="bg-yellow-400 text-yellow-900 px-4 py-2 rounded-full font-bold text-sm shadow-sm">
                  ✨ NEW BEST SCORE ✨
                </span>
              </div>
            )}
          </>
        )}

        <div className="flex flex-col space-y-3">
          <button
            onClick={onRestart}
            className="w-full bg-orange-500 text-white font-bold py-4 rounded-2xl hover:bg-orange-600 active:scale-95 transition-all shadow-lg"
          >
            Play Again
          </button>
          <button
            onClick={onHome}
            className="w-full bg-gray-100 text-gray-700 font-bold py-4 rounded-2xl hover:bg-gray-200 active:scale-95 transition-all"
          >
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default GameOverModal;
